from databaseManager import DatabaseManager

# Global variable to store the database object
# This will be initialized from the main with proper exception handling
db = None


